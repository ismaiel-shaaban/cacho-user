import React from 'react'

const Footer = () => {
  return (
    <div className='text-primary'>  Footer</div>
  )
}

export default Footer