
export default function Home() {
  return (
    <div className='text-primary'>Home</div>
  )
}
